<?php

declare(strict_types=1);

if (PHP_SAPI !== 'cli') {
    http_response_code(404);
    exit;
}

require_once __DIR__ . '/../config/database.php';

$tabelasObrigatorias = [
    'auditoria',
    'categorias',
    'conteudo_tags',
    'conteudos',
    'eventos',
    'midias',
    'tags',
    'usuarios',
    'configuracao_inicio',
];

$colunasObrigatorias = [
    'usuarios' => ['senha_hash', 'perfil', 'status', 'criado_em', 'atualizado_em'],
    'categorias' => ['slug', 'ordem', 'ativo', 'criado_em', 'atualizado_em'],
    'conteudos' => [
        'slug',
        'resumo',
        'corpo',
        'imagem_capa',
        'imagens',
        'autor_id',
        'status',
        'destaque',
        'destaque_em',
        'publicado_em',
        'criado_em',
        'atualizado_em',
    ],
    'configuracao_inicio' => ['titulo', 'descricao', 'imagem', 'imagem_alt', 'imagem_posicao', 'atualizado_por'],
];

$stmtTabelas = $pdo->query(
    "SELECT table_name
     FROM information_schema.tables
     WHERE table_schema = 'public'
     ORDER BY table_name"
);
$tabelasEncontradas = $stmtTabelas->fetchAll(PDO::FETCH_COLUMN);
$problemas = [];

foreach ($tabelasObrigatorias as $tabela) {
    if (!in_array($tabela, $tabelasEncontradas, true)) {
        $problemas[] = "Tabela ausente: {$tabela}";
    }
}

$stmtColunas = $pdo->prepare(
    "SELECT column_name
     FROM information_schema.columns
     WHERE table_schema = 'public' AND table_name = :tabela"
);

foreach ($colunasObrigatorias as $tabela => $colunas) {
    $stmtColunas->execute(['tabela' => $tabela]);
    $encontradas = $stmtColunas->fetchAll(PDO::FETCH_COLUMN);

    foreach ($colunas as $coluna) {
        if (!in_array($coluna, $encontradas, true)) {
            $problemas[] = "Coluna ausente: {$tabela}.{$coluna}";
        }
    }
}

$contagens = [];
foreach (['usuarios', 'categorias', 'conteudos'] as $tabela) {
    if (in_array($tabela, $tabelasEncontradas, true)) {
        $contagens[$tabela] = (int) $pdo->query("SELECT COUNT(*) FROM {$tabela}")->fetchColumn();
    }
}

$conexao = $pdo->query(
    'SELECT current_user AS usuario, inet_server_addr()::text AS servidor,
            inet_server_port() AS porta,
            (SELECT ssl FROM pg_stat_ssl WHERE pid = pg_backend_pid()) AS ssl,
            version() AS versao'
)->fetch();

echo json_encode(
    [
        'banco' => (string) $pdo->query('SELECT current_database()')->fetchColumn(),
        'conexao' => $conexao,
        'valido' => $problemas === [],
        'problemas' => $problemas,
        'tabelas' => $tabelasEncontradas,
        'registros_preservados' => $contagens,
    ],
    JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE
), PHP_EOL;

exit($problemas === [] ? 0 : 1);
